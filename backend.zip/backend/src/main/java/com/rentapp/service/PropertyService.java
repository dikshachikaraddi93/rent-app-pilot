package com.rentapp.service;

import com.rentapp.entity.Property;

import java.util.List;
import java.util.Optional;

public interface PropertyService {

    Property saveProperty(Property property);

    List<Property> getAllProperties();

    Optional<Property> getPropertyById(Long id);

    Property updateProperty(Long id, Property property);

    void deleteProperty(Long id);
}