package com.rentapp.service.impl;

import com.rentapp.entity.Property;
import com.rentapp.repository.PropertyRepository;
import com.rentapp.service.PropertyService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PropertyServiceImpl implements PropertyService {

    private final PropertyRepository propertyRepository;

    public PropertyServiceImpl(PropertyRepository propertyRepository) {
        this.propertyRepository = propertyRepository;
    }

    @Override
    public Property saveProperty(Property property) {
        return propertyRepository.save(property);
    }

    @Override
    public List<Property> getAllProperties() {
        return propertyRepository.findAll();
    }

    @Override
    public Optional<Property> getPropertyById(Long id) {
        return propertyRepository.findById(id);
    }

    @Override
    public Property updateProperty(Long id, Property property) {

        Property existingProperty = propertyRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Property not found"));

        existingProperty.setPropertyName(property.getPropertyName());
        existingProperty.setPropertyType(property.getPropertyType());
        existingProperty.setAddress(property.getAddress());
        existingProperty.setTotalUnits(property.getTotalUnits());
        existingProperty.setOccupiedUnits(property.getOccupiedUnits());
        existingProperty.setMonthlyRent(property.getMonthlyRent());

        return propertyRepository.save(existingProperty);
    }

    @Override
    public void deleteProperty(Long id) {
        propertyRepository.deleteById(id);
    }
}