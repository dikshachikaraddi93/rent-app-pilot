import { BrowserRouter, Routes, Route } from "react-router-dom";

import Dashboard from "./pages/Dashboard";
import Properties from "./pages/Properties";
import Tenants from "./pages/Tenants";
import Payments from "./pages/Payments";
import Reports from "./pages/Reports";

import "./styles/App.css";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Dashboard */}
        <Route path="/" element={<Dashboard />} />

        {/* Property Management */}
        <Route path="/properties" element={<Properties />} />

        {/* Tenant Management */}
        <Route path="/tenants" element={<Tenants />} />

        {/* Payment Management */}
        <Route path="/payments" element={<Payments />} />

        {/* Reports */}
        <Route path="/reports" element={<Reports />} />

        {/* 404 Page */}
        <Route
          path="*"
          element={
            <div
              style={{
                textAlign: "center",
                marginTop: "100px",
                fontSize: "24px",
                fontWeight: "bold",
              }}
            >
              404 - Page Not Found
            </div>
          }
        />
      </Routes>
    </BrowserRouter>
  );
}

export default App;