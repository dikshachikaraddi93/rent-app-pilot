function Reports() {
  return (
    <div style={{ padding: "30px" }}>
      <h1>Reports</h1>
    </div>
  );
}

export default Reports;