function PendingPayments() {
  return (
    <div>
      <h2>Pending Payments</h2>
    </div>
  );
}

export default PendingPayments;