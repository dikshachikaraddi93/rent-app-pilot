import { NavLink } from "react-router-dom";
import {
  FaHome,
  FaBuilding,
  FaUsers,
  FaMoneyBillWave,
  FaChartBar,
  FaCog,
} from "react-icons/fa";

function Sidebar() {
  const menuItems = [
    {
      name: "Dashboard",
      path: "/",
      icon: <FaHome />,
    },
    {
      name: "Properties",
      path: "/properties",
      icon: <FaBuilding />,
    },
    {
      name: "Tenants",
      path: "/tenants",
      icon: <FaUsers />,
    },
    {
      name: "Payments",
      path: "/payments",
      icon: <FaMoneyBillWave />,
    },
    {
      name: "Reports",
      path: "/reports",
      icon: <FaChartBar />,
    },
    {
      name: "Settings",
      path: "/settings",
      icon: <FaCog />,
    },
  ];

  return (
    <aside className="sidebar">
      <div className="logo">
        <h2>🏠 Rent APP</h2>
        <p>Pilot</p>
      </div>

      <nav>
        {menuItems.map((item) => (
          <NavLink
            key={item.name}
            to={item.path}
            className={({ isActive }) =>
              isActive ? "menu active" : "menu"
            }
          >
            {item.icon}
            <span>{item.name}</span>
          </NavLink>
        ))}
      </nav>
    </aside>
  );
}

export default Sidebar;