function SummaryCard({ title, amount, color }) {
  return (
    <div
      style={{
        background: "#fff",
        padding: "20px",
        borderRadius: "12px",
        boxShadow: "0 2px 10px rgba(0,0,0,0.1)",
        borderLeft: `6px solid ${color}`,
      }}
    >
      <h3>{title}</h3>

      <h1>{amount}</h1>
    </div>
  );
}

export default SummaryCard;