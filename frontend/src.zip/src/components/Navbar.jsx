function Navbar() {
  return (
    <div className="navbar">

      <div>
        <h2>Dashboard</h2>
        <p>Welcome back 👋</p>
      </div>

      <input
        type="text"
        placeholder="Search..."
      />

      <div className="nav-right">
        🔔
        <img
          src="https://i.pravatar.cc/40"
          alt="profile"
          className="profile"
        />
      </div>

    </div>
  );
}

export default Navbar;